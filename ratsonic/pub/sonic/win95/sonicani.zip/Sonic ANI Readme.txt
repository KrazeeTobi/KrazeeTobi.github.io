=======================================================================

      Sonic the Hedgehog Animated Cursors version 3.1 TURBO 28/9/96

                http://dspace.dial.pipex.com/watts/andy/

                          sonic@dial.pipex.com

=======================================================================

NEW! - New Wait Sonic Cursor and Tails cursors and Shaded Pointers!

NOTE:  These are 256 colour cursors and look best on a High/True colour 
graphics card.

They were created using bitmaps from Sonic Team's home page, check my
page (above) for a link!

Here's how to use them:

1.  Unzip using Winzip to C:\WINDOWS\CURSORS
2.  Go into the Mouse icon in Control Panel
3.  Click the Pointers tab
4.  Select Working In Background and click browse
5.  Select Sonic Background
6.  Click Open
7.  Select Busy and click browse
8.  Select Sonic Busy
9.  Click Open
10. Click OK and the speediest cursors around are yours!

If you need any more help, don't hesitate to drop me an email!

I require NO registration fee, these cursors are FREEWARE!  Please
spread them!  Please keep this zip file intact and distribute this
readme file with them.  All I ask is that if you have any cool icons,
cursors that are not in my collection - mail them to me!  The same 
goes for any cool GIF/JPG/BMP pix you may have!

Visit my web page for the most comprehensive collection of 256 colour
icons and animated cursors!

        ___------__     .o00o.  .o00o.  .o00o.  .o00o.  .o00o.  .o00o.
 |\__-- /\       _ -    O                                            O
 |/    __       _       O                  Andy Watts                O
 //\  /  \     /__      O             sonic@dial.pipex.com           O
 |  o|  0|__      --_   O                                            O
 \\____-/ __ \   ___ -  O                   Home Page                O
 (@@   ___/  / /_       O                                            O
    -_____---   --_     O  http://dspace.dial.pipex.com/watts/andy/  O
    //  \ \\       -    O                                            O
  //|\__/  \\   ___ -   O   IRC nick: Sonic_H "Sonic the Hedgehog"   O
  \_\\_____/  \-\       O                                            O
      // \\--\|         O       "Gotta juice for a chilli dog!"      O
 ____//  ||_            O                                            O
/___//_\ /___\          .o00o.  .o00o.  .o00o.  .o00o.  .o00o.  .o00o.
