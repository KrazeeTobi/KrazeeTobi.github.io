        ___------__     .o00o.  .o00o.  .o00o.  .o00o.  .o00o.  .o00o.
 |\__-- /\       _ -    O                                            O
 |/    __       _       O                  Andy Watts                O
 //\  /  \     /__      O             sonic@dial.pipex.com           O
 |  o|  0|__      --_   O                                            O
 \\____-/ __ \   ___ -  O   IRC nick: Sonic_H "Sonic the Hedgehog"   O
 (@@   ___/  / /_       O                                            O
    -_____---   --_     O             NEW  Home Page  NEW            O
    //  \ \\       -    O                                            O
  //|\__/  \\   ___ -   O  http://dspace.dial.pipex.com/watts/andy/  O
  \_\\_____/  \-\       O                                            O
      // \\--\|         O    Keeper of the Happy Icon Collection     O
 ____//  ||_            O                                            O
/___//_\ /___\          .o00o.  .o00o.  .o00o.  .o00o.  .o00o.  .o00o.