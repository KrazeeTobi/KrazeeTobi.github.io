=======================================================            ====
SONIC THE HEDGEHOG THEME FOR WINDOWS 95 & MS PLUS! v3.1     
                                                                   :o)
        http://dspace.dial.pipex.com/watts/andy/
=======================================================            ====

NOTE:  WIN95, MS PLUS AND A HIGH COLOUR GRAPHICS CARD REQUIRED

Hi there, fellow freedom fighters!  Here's a way past cool theme for 
all you Sonic fans!

To use this theme, unzip it using Winzip 95 to C:\ and it will make its
own folder in your themes folder.  Then change the theme by going to
the Themes control panel and selecting Sonic the Hedgehog.  Make sure you
have MS Plus to set up Stretch Wallpaper to Full Screen!

NOTE: To use the extra cursors, icons and shutdown/startup screens, you will 
have to set them up manually.

NEW in version 3.1:

* NEW ICONS FOR THE RECYCLE BIN
* EVEN MORE ICONS!

Here is how I put it together:

Wallpaper	Made from various images from the net
Sounds		Sampled directly from the Sonic 1 @22khz 8bit
Cursors		Made using bitmaps taken strait from Sonic 2
Icons		The sonic icon is drawn by me, the tails icon is made 
		from a pic the others are from various sources.

I require NO registration fee, this theme FREEWARE!  Please spread it 
to all your friends!  Please keep this zip file intact and distribute 
this readme file with them.  All I ask is that if you have any cool 
icons, cursors that are not in my collection - mail them to me!  The 
same goes for any cool Sonic pix you may have!

If you like the icons I also have an icon collection for Windows 95 
called The Happy Icon Collection, available to download from my web 
page.  It contains many unique 256 colour icons such as game icons,
toons, people and even more sonic icons!

Thanks for taking the trouble to look at this!

Up, over, and gooone!

        ___------__     .o00o.  .o00o.  .o00o.  .o00o.  .o00o.  .o00o.
 |\__-- /\       _ -    O                                            O
 |/    __       _       O                  Andy Watts                O
 //\  /  \     /__      O             sonic@dial.pipex.com           O
 |  o|  0|__      --_   O                                            O
 \\____-/ __ \   ___ -  O                   Home Page                O
 (@@   ___/  / /_       O                                            O
    -_____---   --_     O  http://dspace.dial.pipex.com/watts/andy/  O
    //  \ \\       -    O                                            O
  //|\__/  \\   ___ -   O   IRC nick: Sonic_H "Sonic the Hedgehog"   O
  \_\\_____/  \-\       O                                            O
      // \\--\|         O       "Gotta juice for a chilli dog!"      O
 ____//  ||_            O                                            O
/___//_\ /___\          .o00o.  .o00o.  .o00o.  .o00o.  .o00o.  .o00o.
