Sonic Robo Halloween Blast! Version 1.32
from
Sonic Team Junior
---------------------------
Ah yes, RetroGaming! Don't you just love it? Here's a Win32 port of last year's
"Sonic Robo Halloween Blast" with a few little fixups from last time, and an
extra level. Please don't report any bugs you find.

TRY OUT THE NETPLAY!

Although still not completely optimized/finished, you can take netplay for a spin
by using the launcher provided. Broadband connection recommended (or use a LAN).

Level 1 - A.J. Freda
Level 2 - Johnny Wallbank

Questions? Comments?
http://stjr.cjb.net
sonikku@emulationzone.org
ah518@tcnet.org
