Sonic Robo Halloween Blast!
from
Sonic Team Junior
---------------------------
Q: Why does this use the Sonic X-Treme sprites?

A: Because the SRB2 ones aren't done yet.

---------------------------

Here's a little something we threw together using the Alpha SRB2 engine as the core.
Please report any bugs you find except for the following known ones:

1. Sonic will not spin when he jumps
2. You can see the water over other objects
3. Ghosts are not hittable from the top or bottom
4. Sonic will sometimes stand up when he dies
5. One of the spots in the fence area flickers and messes up sometimes. To fix this,
   only cross the fence entrance once at the start of the level.

The object of this game is to find every single ring and destroy every ghost and clear
the level as fast as you can! Think you're good? run RECWEEN.BAT to record your play and
e-mail the MYDEMO.LMP file it creates to:

ah518@tcnet.org

Times will be posted on the Sonic Team Jr. Website!
http://stjr.segasonic.net

PLAY OVER A NETWORK!

This lets you play up to four players together over a network using the IPX protocol.
To play, just have each computer run "IPXSETUP" and you're all set!
