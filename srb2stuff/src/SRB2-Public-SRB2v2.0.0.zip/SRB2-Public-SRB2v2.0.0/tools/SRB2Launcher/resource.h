//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_MAIN                        101
#define IDB_BITMAP1                     102
#define IDI_ICON1                       103
#define IDD_JOINGAME                    104
#define IDD_HOSTGAME                    106
#define IDD_MATCHOPTIONS                108
#define IDD_RACEOPTIONS                 109
#define IDD_CTFOPTIONS                  110
#define IDD_TAGOPTIONS                  111
#define IDC_GO                          1001
#define IDC_LAUNCHCONFIG                1002
#define IDC_EXTFILECOMBO                1003
#define IDC_ABOUT                       1005
#define IDC_ADDFILE                     1006
#define IDC_REMOVEFILE                  1007
#define IDC_SAVELAUNCHCFG               1008
#define IDC_JOINGAME                    1010
#define IDC_HOSTGAME                    1011
#define IDC_SOUNDOPTS                   1012
#define IDC_PARAMETERS                  1013
#define IDC_EXENAME                     1014
#define IDC_FINDEXENAME                 1015
#define IDC_SEARCHGAMES                 1016
#define IDC_GAMELIST                    1018
#define IDC_NAME                        1020
#define IDC_COLOR                       1021
#define IDC_SKIN                        1022
#define IDC_ADDRESS                     1023
#define IDC_NOFILE                      1024
#define IDC_JOINSTART                   1026
#define IDC_NODOWNLOAD                  1027
#define IDC_OPTIONS                     1028
#define IDC_GAMETYPE                    1029
#define IDC_MAXPLAYERS                  1030
#define IDC_STARTMAP                    1031
#define IDC_FORCESKIN                   1032
#define IDC_ADVANCEMAP                  1033
#define IDC_INTERNETSERVER              1034
#define IDC_SPECIALRINGS                1036
#define IDC_MATCHBOXES                  1037
#define IDC_OK                          1038
#define IDC_CANCEL                      1039
#define IDC_RESPAWNITEMTIME             1040
#define IDC_TIMELIMIT                   1041
#define IDC_POINTLIMIT                  1042
#define IDC_FLAGTIME                    1048
#define IDC_RACEITEMBOXES               1051
#define IDC_NUMLAPS                     1052
#define IDC_SUDDENDEATH                 1060
#define IDC_MATCH_SCORING               1061
#define IDC_INTTIME                     1064
#define IDC_DISABLEAUTOAIM              1065
#define IDC_MONITORTOGGLES              1067
#define IDC_CONFIGFILE                  1069
#define IDC_FINDCONFIGNAME              1070
#define IDC_LIST1                       1071

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1072
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
