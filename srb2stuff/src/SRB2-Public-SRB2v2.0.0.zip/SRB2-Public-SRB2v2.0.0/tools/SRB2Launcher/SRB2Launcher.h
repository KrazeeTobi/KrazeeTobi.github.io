extern char TempString[256];
extern char EXEName[1024];
extern char Arguments[16384];

#define APPTITLE "Official Sonic Robo Blast 2 Launcher"
#define APPVERSION "v0.1"
#define APPAUTHOR "SSNTails"
#define APPCOMPANY "Sonic Team Junior"
