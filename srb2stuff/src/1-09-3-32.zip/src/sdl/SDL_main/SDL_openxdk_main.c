
/* Include the SDL main definition header */
#include "SDL_main.h"

void XBoxStartup()
{
	SDL_main(0, NULL); /// \todo ?
}
