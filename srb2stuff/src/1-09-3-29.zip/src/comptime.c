/*
 * Compile date and time.
 */

const char *compdate = __DATE__;
const char *comptime = __TIME__;
