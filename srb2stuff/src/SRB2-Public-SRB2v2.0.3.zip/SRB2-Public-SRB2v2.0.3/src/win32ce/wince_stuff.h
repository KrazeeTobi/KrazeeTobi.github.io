#ifndef WINCE_STUFF_H
#define WINCE_STUFF_H

/*
char* _strlwr(char *string);
int _strnicmp(const char *string1,const char *string2, size_t count );
int _stricmp( const char *string1, const char *string2 );
char* _strupr( char *string );

char *_strdup( const char *strSource );
char *strrchr( const char *string, int c );

int isprint( int c );
*/
char* GetMyCWD(void);

#endif