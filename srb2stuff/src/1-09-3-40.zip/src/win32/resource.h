//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Srb2win.rc
//
#define IDI_DLICON1                     101
#define IDC_DLCURSOR1                   103
#define IDI_ICON1                       106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
