#include "../i_net.h"

boolean I_InitNetwork(void)
{
	return false;
}
