sh-elf-objcopy -R .stack -O binary ../bin/DC/SRB2.elf ../bin/DC/SRB2DC.BIN
./sdl/SRB2DC/scramble ../bin/DC/SRB2DC.BIN ../bin/DC/1ST_READ.BIN
echo LINUX: http://www.ele.uva.es/~jesus/dream/
echo WIN32: http://www.emutalk.net/showthread.php?s=de9ed841c3c979055d52b7972fd179e3&t=24918
echo 
