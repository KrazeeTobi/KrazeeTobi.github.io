SONIC ROBO BLAST 1.3f, last minute notes...
----

As the installation shield wouldn't work, we had to take it out, therefore, you will merely
have to manually install it. Copy, from your WinZip folder, the files and paste them where
you feel they should be. (ie, c:\games\srb) Next, put the cncs32.dll file in your Windows\System directory. Not only will this help Sonic Robo Blast work, but it will make other games work too.

Now, enjoy!

--
Sonikku