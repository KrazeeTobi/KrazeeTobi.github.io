SONIC ROBO BLAST 2

Sonic Robo Blast 2 (SRB2) is a 3D Sonic the Hedgehog fangame based on a
modified version of Doom Legacy.

LICENSE

The source code for SRB2 is licensed under the GNU General Public
License, Version 2. See LICENSE.txt for the full text of this license.

SRB2 uses various third-party libraries, including SDL, SDL Mixer, and
their dependencies. See LICENSE-3RD-PARTY.txt for the licenses of these
libraries.

SOURCE CODE

You may obtain the source code for SRB2, including the source code for
specific version releases, at the following web sites:

STJr GitLab:
https://git.magicalgirl.moe/STJr/SRB2

GitHub:
https://github.com/STJr/SRB2

CONTACT

You may contact Sonic Team Junior via the following web sites:

SRB2.ORG:
https://www.srb2.org

SRB2 Message Board:
https://mb.srb2.org

SRB2 Official Discord:
https://discord.gg/pYDXzpX

COPYRIGHT AND DISCLAIMER

Design and content on SRB2 is copyright 1998-2018 by Sonic Team Junior.
All non-original material on SRB2.ORG is copyrighted by their
respective owners, and no copyright infringement is intended. The owner
of the SRB2.ORG domain is only acting as an ISP, and is therefore not
responsible for any content on SRB2.ORG under the 1998 DMCA. This
site, its webmaster, and its staff make no profit whatsoever (in fact,
we lose money). Sonic Team Junior assumes no responsibility for the
content on any Sonic Team Junior fan sites.

Sonic Team Junior is in no way affiliated with SEGA or Sonic Team. We do
not claim ownership of any of SEGA's intellectual property used in SRB2.
