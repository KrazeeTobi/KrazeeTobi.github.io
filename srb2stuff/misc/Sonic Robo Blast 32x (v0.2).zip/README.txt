____________________
SONIC ROBO BLAST 32X
____________________

Platform : Sega 32x
Description : You waited for it and here it is !
This is a attempt to port some SRB2 levels to the Sega 32X. 
Currently , 2 levels are optimized for the 32X and 2 levels are exclusive.

Improvements in comparison to my previous hacks :
-You can now see Sonic's face (it was black before)
-Third-person view instead of the first person view.

Hopefully it will be complete during my vacations.

http://gameblabla.netai.net
http://www.youtube.com/user/gameblabla


