/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=
*                     SNES PRO                     *
*           http://www.snespro.com                 *
=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/
*                                                  *
* This Rom was obtained from SNES Pro.             *
* We hold the TOP emulators you will need to play  *
* the roms. We have QUALITY roms that are reliable *
* and available to download anytime!               *  
* Our roms are not linked to other sites.          *
* We also have a review for each rom, so you will  *
* have a better knowledge of the game you're       *
* downloading!                                     *
* SNES Pro is constantly adding new roms to our    *
* database, along with our detailed reviews for    *
* each of them! This site is easy to navigate      *
* without annoying pop-ups or porn links.          *
* And also, Updated frequently.                    *
*                                                  *
* If you have not paid for, and/or own the actual  *
* game itself then please delete this Rom within   * 
* 24 hours.  =)                                    *
*                                                  *
/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=
*                     SNES PRO                     *
*           http://www.snespro.com                 *
*           Please visit us again soon!            *
=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/=/