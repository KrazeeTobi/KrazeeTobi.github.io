Just thought I'd let you know that this file was originally downloaded
from "The SNES Cauldron". It may have been passed from site to site but 
the original location to where this ROM was snatched from is given below.

Here's a quick text banner for decoration:

       -------------------------------------------------
       |******************  SNES-C ********************|
       |     - Where all your SNES dreams come true!   |
       |    					       |
       |     http://129.78.64.1:9801/snescauldron      |
       |     email : snescauldron@hotmail.com          |
       |Brief Description of site :                    |
       |Features includes Instant chat with other      |
       |gamers, online reviews, ROM voting, ROM search |
       |avatar chat world, message board and many more.|
       -------------------------------------------------


This blatant promo was written on the 22 Feb 1998.
