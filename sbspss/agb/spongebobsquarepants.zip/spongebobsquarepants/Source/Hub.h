//***************************************************************************************************
// Project:		SpongeBob Squarepants GBA.
// Source:		Text System (Header).
// Author:		RCA Duff.
// (C) 2000/1:	Climax.
//***************************************************************************************************

#ifndef _HUB_H
#define _HUB_H


//functions          
void InitHub(void);          
void MainHub(void);
          
#endif