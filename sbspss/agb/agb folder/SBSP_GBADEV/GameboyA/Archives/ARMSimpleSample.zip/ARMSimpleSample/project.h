/*============================================================================
		Nintendo of America Developer Support
		Scott Perras
============================================================================*/
//all files get this included!

#ifndef PROJECT_H
#define PROJECT_H

#define DEBUG_VERSION

#include <agb.h>
#include <stdio.h>
#include <stdlib.h>

#include "defs.h"

#endif
