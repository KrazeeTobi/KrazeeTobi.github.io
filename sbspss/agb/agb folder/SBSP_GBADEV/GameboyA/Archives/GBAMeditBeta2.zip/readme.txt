------------------------------------------------------------------
				GBA Map Editor Beta 2
------------------------------------------------------------------
About
------------------------------------------------------------------
Beta 2
------------------------------------------------------------------
Second release.  sgstair added zoom and now the map name is saved
Also a paint bucked has been added.  It's under tools.
------------------------------------------------------------------
Beta 1
------------------------------------------------------------------
This is the first release of the GBA Map Editor.  It is very basic
there are really no extra features.  Eventually a zoom, and block
select will be added, as well as other things, like I said this is
a basic release.  Save/load/export all work so it is usuable, just
not pretty.
------------------------------------------------------------------
Controls
------------------------------------------------------------------
Left Mouse	-	Places a tile, or selects the tile
Right Mouse	-	Opens a menu on the map screen to select tools
Ctrl+Alt+Shift+7 - Ultra secret hyper mode, or not
------------------------------------------------------------------
Usage
------------------------------------------------------------------
Before you start you need to load a tile set.  Click change tiles
and select a .bmp.  Now you can select different tiles and draw 
with it.  When you are ready to use the map in gba you can use
export to .c.  Make sure you export your tiles using tilestripper
and hackit.  I'm not gonna go into specifics on how to use the
map in your code, I'll write a few tutorials after the map editor
gets into a more final state.
------------------------------------------------------------------
Thanks to:
------------------------------------------------------------------
Yozzi and sgstair on efnet
------------------------------------------------------------------
Visit #gbadev on efnet
and
my website at:
www.nolag.com/code/gbdev

Warder1
warder@nolag.com