//======================================================
//    menu_bmp.h
//    Image Data Header for Menu of Sample Yoshi
//
//    Copyright (C) 1999-2000 NINTENDO Co.,Ltd.
//======================================================
#ifndef MENU_BMP_H
#define MENU_BMP_H
extern const u8 _binary_umi64_imb_start[8*8*(64/8/1)*(64/8)];
extern const u8 _binary_kumo_imb_start[8*8*(32/8/1)*(32/8)];
extern const u8 _binary_grade_imb_start[8*8*(32/8/1)*(32/8)];
#endif
