//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NewAVI2BMP.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NEWAVITYPE                  129
#define IDD_FILEINFO                    132
#define IDD_MYCONVERT                   133
#define IDC_LZ77                        1001
#define IDC_RLE                         1002
#define IDC_DIFF                        1003
#define IDC_S2                          1004
#define IDC_S4                          1005
#define IDC_S8                          1006
#define IDC_EDIT1                       1007
#define IDC_BSZ8                        1007
#define IDC_EDIT2                       1008
#define IDC_BSZ16                       1008
#define IDC_EDIT3                       1009
#define IDC_LZ78                        1009
#define IDC_EDIT4                       1010
#define IDC_EDIT5                       1011
#define IDC_EDIT6                       1012
#define IDC_EDIT7                       1013
#define ID_AVI_DETAILS                  32771
#define ID_AVI_CONVERT                  32772
#define ID_AVI_NEXT                     32773
#define ID_AVI_PREVIOUS                 32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
