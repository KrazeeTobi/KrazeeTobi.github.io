//======================================================
//    bitmap.h   
// 	Btimap control                                        
//                                                      
//    Copyright (C) 1999, NINTENDO Co., Ltd.             
//======================================================

#ifndef	__BITMAP_H__
#define	__BITMAP_H__

#include <agb.h>

#undef	NULL
#define	NULL	((void *)0)

//-------------------- Functions ----------------------
void bm_Main();
//-----------------------------------------------------

#endif	//  __BITMAP_H__
