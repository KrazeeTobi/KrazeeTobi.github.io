/********************************************************************/
/*      mylib.h                                                     */
/*          Personal Library Header Include                         */
/*                                                                  */
/*              Copyright (C) 1999-2001 NINTENDO Co.,Ltd.           */
/********************************************************************/
#ifndef	__MYLIB_H__
#define	__MYLIB_H__

#include "myTypes.h"
#include "bg.h"
#include "obj.h"
#include "stdSub.h"

#endif		// __MYLIB_H__
