fighter demo by dovoto (www.agbdev.net/thePERNproject)tested on real
 hardware.  Press the buttons.
graphics by cuchipandi @ cuchipandi@jazzartistas.com  they are looking
for coders
(sorry they made me say it ;)