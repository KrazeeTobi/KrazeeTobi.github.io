#ifndef _ar_temp_h
#define _ar_temp_h

extern char _binary_archer_pal_bin_start[32];
extern char _binary_archer_idle_bin_start[512];
extern char _binary_archer_walk_bin_start[5120];
extern char _binary_archer_defend_bin_start[2560];
extern char _binary_archer_die_bin_start[3072];
extern char _binary_archer_react_bin_start[3072];
extern char _binary_archer_shoot_bin_start[2560];

#endif /* _ar_temp_h */
#ifndef _ar_temp1_h
#define _ar_temp1_h

extern char _binary_archer_attack_bin_start[3072];
extern char _binary_arrow_bin_start[128];
extern char _binary_arrow_1_bin_start[128];

#endif /* _ar_temp1_h */
