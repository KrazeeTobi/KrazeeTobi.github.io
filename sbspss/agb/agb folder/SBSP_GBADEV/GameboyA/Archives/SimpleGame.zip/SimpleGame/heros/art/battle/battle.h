#ifndef _BATTLE_ART_H
#define _BATTLE_ART_H

#include "art\battle\scenes\scenes.h"
#include "art\battle\heros\battlehorses.h"

#endif // _BATTLE_ART_H
