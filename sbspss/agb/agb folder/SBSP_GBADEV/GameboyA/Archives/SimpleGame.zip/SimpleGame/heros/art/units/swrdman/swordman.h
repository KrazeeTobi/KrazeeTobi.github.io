#ifndef _sw_temp_h
#define _sw_temp_h

extern char _binary_swordman_pal_bin_start[32];
extern char _binary_swordman_idle_bin_start[512];
extern char _binary_swordman_attack_bin_start[3072];
extern char _binary_swordman_die_bin_start[2560];
extern char _binary_swordman_defend_bin_start[2048];

#endif /* _sw_temp_h */
#ifndef _sw_temp1_h
#define _sw_temp1_h

extern char _binary_swordman_react_bin_start[2560];
extern char _binary_swordman_walk_bin_start[4608];

#endif /* _sw_temp1_h */
