#ifndef _sw_temp_h
#define _sw_temp_h

extern char binary_swordman_pal_bin_start[32];
extern char binary_swordman_idle_bin_start[512];
extern char binary_swordman_attack_bin_start[3072];
extern char binary_swordman_die_bin_start[2560];
extern char binary_swordman_defend_bin_start[2048];

#endif /* _sw_temp_h */
