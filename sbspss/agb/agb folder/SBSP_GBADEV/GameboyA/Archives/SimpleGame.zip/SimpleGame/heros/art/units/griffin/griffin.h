#ifndef _griffin_h
#define _griffin_h

extern char _binary_griffin_pal_bin_start[32];
extern char _binary_griffin_idle_bin_start[512];

#endif /* _griffin_h */
