#ifndef _castle_units_h
#define _castle_units_h

#include "art/units/archer/archer.h"
#include "art/units/cavalier/cavalier.h"
#include "art/units/griffin/griffin.h"
#include "art/units/monk/monk.h"
#include "art/units/pikeman/pikeman.h"
#include "art/units/swrdman/swordman.h"

#endif // _castle_units_h
