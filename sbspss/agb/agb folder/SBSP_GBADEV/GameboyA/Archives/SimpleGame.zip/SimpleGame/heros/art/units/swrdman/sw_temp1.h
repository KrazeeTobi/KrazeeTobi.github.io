#ifndef _sw_temp1_h
#define _sw_temp1_h

extern char binary_swordman_react_bin_start[2560];
extern char binary_swordman_walk_bin_start[4608];

#endif /* _sw_temp1_h */
