#ifndef _ar_temp_h
#define _ar_temp_h

extern char binary_archer_pal_bin_start[32];
extern char binary_archer_idle_bin_start[512];
extern char binary_archer_walk_bin_start[5120];
extern char binary_archer_defend_bin_start[2560];
extern char binary_archer_die_bin_start[3072];
extern char binary_archer_react_bin_start[3072];
extern char binary_archer_shoot_bin_start[2560];

#endif /* _ar_temp_h */
