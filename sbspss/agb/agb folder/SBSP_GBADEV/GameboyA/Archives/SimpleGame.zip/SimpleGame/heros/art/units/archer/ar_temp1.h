#ifndef _ar_temp1_h
#define _ar_temp1_h

extern char binary_archer_attack_bin_start[3072];
extern char binary_arrow_bin_start[128];
extern char binary_arrow_1_bin_start[128];

#endif /* _ar_temp1_h */
