#ifndef _battlehorses_h
#define _battlehorses_h

extern char _binary_female_battle_horse_bin_start[288];
extern char _binary_female_goblin_battle_horse_bin_start[288];

#endif /* _battlehorses_h */
