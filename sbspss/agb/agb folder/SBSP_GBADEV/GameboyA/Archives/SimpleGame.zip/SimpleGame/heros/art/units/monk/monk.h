#ifndef _monk_h
#define _monk_h

extern char _binary_monk_pal_bin_start[32];
extern char _binary_monk_idle_bin_start[2560];
extern char _binary_monk_walk_bin_start[3072];
extern char _binary_monk_react_bin_start[3072];
extern char _binary_monk_shoot_bin_start[2560];
extern char _binary_monk_die_bin_start[5120];
extern char _binary_monk_defend_bin_start[2560];

#endif /* _monk_h */
