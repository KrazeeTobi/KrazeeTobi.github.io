#ifndef _pikeman_h
#define _pikeman_h

extern char _binary_pikeman_pal_bin_start[32];
extern char _binary_pikeman_idle_bin_start[256];

#endif /* _pikeman_h */
