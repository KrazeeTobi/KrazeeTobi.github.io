#ifndef _HEROART_H
#define _HEROART_H

//#include "art\battle\scenes\scenes.h"
//#include "art\battle\heros\battlehorses.h"

#include "art\battle\battle.h"
#include "art\units\battleunits.h"

#endif // _HEROART_H
