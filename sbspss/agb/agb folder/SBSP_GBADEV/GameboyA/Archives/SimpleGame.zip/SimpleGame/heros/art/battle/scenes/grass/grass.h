#ifndef _grass_h
#define _grass_h

extern char _binary_grass_chr_start[26880];
extern char _binary_grass_map_start[2048];
extern char _binary_grass_pal_start[512];

#endif /* _grass_h */
