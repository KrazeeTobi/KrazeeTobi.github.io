#ifndef _cavalier_h
#define _cavalier_h

extern char _binary_cavalier_pal_bin_start[32];
extern char _binary_cavalier_idle_bin_start[1024];
extern char _binary_cavalier_attack_bin_start[9216];
extern char _binary_cav_defend_bin_start[6144];
extern char _binary_cav_die_bin_start[8192];
extern char _binary_cav_react_bin_start[7168];
extern char _binary_cav_walk_bin_start[14336];

#endif /* _cavalier_h */
